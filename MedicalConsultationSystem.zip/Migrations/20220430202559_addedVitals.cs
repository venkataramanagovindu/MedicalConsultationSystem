﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MedicalConsultationSystem.Migrations
{
    public partial class addedVitals : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "Pulse",
                table: "Patient",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "Respirationrate",
                table: "Patient",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "SpO2",
                table: "Patient",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.AddColumn<double>(
                name: "temperature",
                table: "Patient",
                nullable: false,
                defaultValue: 0.0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Pulse",
                table: "Patient");

            migrationBuilder.DropColumn(
                name: "Respirationrate",
                table: "Patient");

            migrationBuilder.DropColumn(
                name: "SpO2",
                table: "Patient");

            migrationBuilder.DropColumn(
                name: "temperature",
                table: "Patient");
        }
    }
}
