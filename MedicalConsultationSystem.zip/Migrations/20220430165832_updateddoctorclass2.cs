﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MedicalConsultationSystem.Migrations
{
    public partial class updateddoctorclass2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "sample",
                table: "Doctor");

            migrationBuilder.AlterColumn<int>(
                name: "Specialization",
                table: "Doctor",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Specialization",
                table: "Doctor",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AddColumn<string>(
                name: "sample",
                table: "Doctor",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
