﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MedicalConsultationSystem.Migrations
{
    public partial class RoomAvailable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "Available",
                table: "Room",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Available",
                table: "Room");
        }
    }
}
