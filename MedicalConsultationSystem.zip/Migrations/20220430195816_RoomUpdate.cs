﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MedicalConsultationSystem.Migrations
{
    public partial class RoomUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Patient_RoomID",
                table: "Patient");

            migrationBuilder.DropColumn(
                name: "PatientId",
                table: "Room");

            migrationBuilder.AddColumn<string>(
                name: "Description",
                table: "Room",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Patient_RoomID",
                table: "Patient",
                column: "RoomID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Patient_RoomID",
                table: "Patient");

            migrationBuilder.DropColumn(
                name: "Description",
                table: "Room");

            migrationBuilder.AddColumn<int>(
                name: "PatientId",
                table: "Room",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Patient_RoomID",
                table: "Patient",
                column: "RoomID",
                unique: true);
        }
    }
}
